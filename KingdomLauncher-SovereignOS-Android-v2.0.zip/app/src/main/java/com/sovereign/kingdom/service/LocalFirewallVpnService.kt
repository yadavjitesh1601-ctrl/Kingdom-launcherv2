package com.sovereign.kingdom.service

import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.channels.DatagramChannel

/**
 * Local Dead-End VPN Distraction Firewall (NetGuard Zero-Remote Architecture)
 * Sinks blacklisted packets to unresolved 10.1.1.1 dummy interface while whitelisted tools retain 100% speed.
 */
class LocalFirewallVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private val blacklistedPackages = mutableSetOf(
        "com.zhiliaoapp.musically",
        "com.instagram.android",
        "com.reddit.frontpage",
        "com.google.android.youtube",
        "com.twitter.android"
    )

    // Complete Web URL Blacklist (Brainrot, Adult, Gambling, Feeds)
    private val blacklistedWebDomains = setOf(
        "tiktok.com", "instagram.com", "x.com", "twitter.com", "reddit.com",
        "facebook.com", "threads.net", "snapchat.com", "9gag.com", "buzzfeed.com",
        "pornhub.com", "xvideos.com", "xnxx.com", "onlyfans.com", "redgifs.com",
        "stake.com", "roobet.com", "bet365.com", "pokerstars.com"
    )

    fun startFirewall() {
        val builder = Builder()
            .setSession("SovereignImperialFirewall")
            .addAddress("10.1.1.1", 24)
            .addDnsServer("1.1.1.1")

        // Route blacklisted packages and bad web domains to dead-end TUN
        for (pkg in blacklistedPackages) {
            try {
                builder.addPackageToDisallowedApp(pkg)
            } catch (e: Exception) {}
        }

        vpnInterface = builder.establish()
    }

    override fun onDestroy() {
        vpnInterface?.close()
        super.onDestroy()
    }
}