package com.sovereign.kingdom.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import kotlinx.coroutines.*

/**
 * Sludge-Decay Progressive Screen Degrader
 * Toxic bile-olive tint (#333520) with 0-Order Linear Decay.
 * Drains back to 0% alpha over 1-2 hours of screen-off time (~3x continuous usage).
 */
class SludgeDecayService : Service() {
    private var windowManager: WindowManager? = null
    private var sludgeOverlayView: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var currentAlpha = 0.0f
    private var continuousMinutes = 0
    private var isScreenOn = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        initOverlay()
        startDecayLoop()
    }

    private fun initOverlay() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        sludgeOverlayView = View(this).apply {
            setBackgroundColor(Color.parseColor("#333520"))
            alpha = 0.0f
        }
        windowManager?.addView(sludgeOverlayView, params)
    }

    private fun startDecayLoop() {
        scope.launch {
            while (isActive) {
                delay(60_000L) // 1-minute ticker
                if (isScreenOn) {
                    continuousMinutes++
                    updateSludgeAlpha()
                } else {
                    // Zero-order linear decay: drains over 60-120 minutes
                    val linearDrainStep = 0.75f / 90.0f // ~90 minutes to drain 75%
                    currentAlpha = (currentAlpha - linearDrainStep).coerceAtLeast(0.0f)
                    sludgeOverlayView?.alpha = currentAlpha
                }
            }
        }
    }

    private fun updateSludgeAlpha() {
        currentAlpha = when {
            continuousMinutes <= 10 -> 0.0f
            continuousMinutes in 11..15 -> 0.10f + (continuousMinutes - 10) * 0.04f
            continuousMinutes in 16..25 -> 0.30f + (continuousMinutes - 15) * 0.035f
            else -> 0.75f // Capped at repulsive 75% alpha
        }
        sludgeOverlayView?.alpha = currentAlpha
    }

    override fun onDestroy() {
        scope.cancel()
        if (sludgeOverlayView != null) {
            windowManager?.removeView(sludgeOverlayView)
        }
        super.onDestroy()
    }
}